<template>
  <q-page class=" row justify-center items-center"
  style="background: linear-gradient(#012E57, #012E57);"
  >
    <!-- <div style=" margin-top:50px">
       <q-img
      alt="Quasar logo "
      src="~assets/logo1.png"
      hight="100px"
      width="50px"
      
    >
    </q-img>
    </div> -->

    <div >
      <div  >
       
      <h4 class="text- frutiger text-white text-center q-pa-none text-bold">Login</h4>  
      </div>
      <div style=" margin-bottom:300px" >
       
              <!-- <q-input square filled clearable v-model="Number" type="number" label="Phone-Number" /> -->
            <q-input rounded outlined standout="bg-white text-grey"  style="color: linear-gradient(#ffffff, #ffffff);" type="Number" min="1" max="10" v-model.number="number" label="PHONE NUMBER" ></q-input>
             
          <div style=" margin-left:300px; margin-top:50px " >
            <q-btn unelevated round size="lg" text-color="white" icon="keyboard_arrow_right" style="background: linear-gradient(#f0951f, #f0951f);"  />
          </div>
          
          
            <div class="link text-center q-pa-none">
            <b><p class="text-frutiger text-white">Not reigistered ? <a class="text-frutiger text-white" :href="signup">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Up</a></p></b>
            </div>
         
        
       
      </div>
    </div>
     <q-footer style="background: linear-gradient(#012E57, #012E57);">
        <q-toolbar>
          <q-toolbar-title class="text-frutiger text-center q-pa-none" >By Signing up, you agree to T&C </q-toolbar-title>
        </q-toolbar>
      </q-footer>
  </q-page>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      email: '',
      password: '',
      signup:'#/signup',
      number:''
    }
  }


}
</script>

<style>
.q-card {
  width: 360px;
}
.link a {
    color: #FFFFFF;
    text-decoration: none;
}
</style>