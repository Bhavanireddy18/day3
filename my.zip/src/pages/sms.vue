<template>
  <q-page class="flex flex-center" style="background: linear-gradient(#012E57, #012E57);">
   
      <div fixed-center width="80px" style=" margin-bottom:300px" >
       <q-input rounded outlined standout="bg-white text-grey"  style="color: linear-gradient(#ffffff, #ffffff);" type="Number" min="1" max="10" v-model.number="number" label="PHONE NUMBER" ></q-input>
      </div>
     </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  data(){
  return {
    max: 4,
    otp: ''
  } 

  }

  }
</script>