<template>
  <q-page class="flex flex-center" style="background: linear-gradient(#012E57, #012E57);">
    <q-img
      alt="Quasar logo"
      src="~assets/logo1.png"
      hight="1000px"
      width="300px"
    >
    </q-img>
  </q-page>
</template>


<script>
export default {
  name: 'PageIndex',
  startup() {
    this.sayHi()
  },

sayHi () {
  setTimeout(function () {
    this.$router.push('#/login ');
  }.bind(this),3000);

}
}
</script>