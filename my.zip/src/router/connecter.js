const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
var app = express();

var cors = require('cors');
app.use(cors()); 

//Configuring express server
//app.use(bodyparser.json());


//MySQL details
var mysqlConnection = mysql.createConnection({
  host: 'sql6.freemysqlhosting.net',
  user: 'sql6409218',
  password: 'cQpqQ8PeMW',
  database: 'sql6409218',
  multipleStatements: true
  });

  mysqlConnection.connect((err)=> {
    if(!err)
    console.log('Connection Established Successfully');
    else
    console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
    });

    //Establish the server connection
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}..`));

//Creating GET Router to fetch all the employee details from the MySQL Database
app.get('/employee' , (req, res) => {
  mysqlConnection.query('SELECT * FROM employee', (err, rows, fields) => 
  {
  if (!err)
  res.send(rows);
  else
  console.log(err);
  })
  });

  //Router to GET specific employee detail from the MySQL database
app.get('/employee/:id' , (req, res) => {
  mysqlConnection.query('SELECT * FROM employee WHERE employee_id = ?',[req.params.id], (err, rows, fields) => {
  if (!err)
  res.send(rows);
  else
  console.log(err);
  })
  } );

    //Router to GET specific employee detail using phone number from the MySQL database
app.get('/employee/phoneno/:ph' , (req, res) => {
   
  });



  //Router to INSERT/POST a learner's detail
app.post('/employee/addoredit', (req, res) => {
  let employee = req.body;
  var sql = 
  " SET @EMPLOYEE_ID = ?; SET @EMPLOYEE_TYPE = ?; SET @FIRST_NAME = ?; SET @UNIQUE_ID = ?; SET @GENDER = ?; SET @DATEOFBIRTH = ?; SET @PHONENUMBER = ?; SET @EMAIL_ID = ?; SET @PHOTOGRAPH = ?; SET @START_DATE = ?; SET @END_DATE = ?; SET @ADDRESS = ?; SET @COMMENTS = ?; CALL employeeAddOrEdit(@EMPLOYEE_ID,@EMPLOYEE_TYPE,@FIRST_NAME,@LAST_NAME,@UNIQUE_ID,@GENDER,@DATEOFBIRTH,@PHONENUMBER,@EMAIL_ID,@PHOTOGRAPH,@START_DATE,@END_DATE,@ADDRESS,@COMMENTS);";
   mysqlConnection.query(sql, [employee.EMPLOYEE_ID, employee.EMPLOYEE_TYPE, employee.FIRST_NAME, employee.LAST_NAME,employee.UNIQUE_ID, employee.GENDER, employee.DATEOFBIRTH, employee.PHONENUMBER, employee.EMAIL_ID, employee.PHOTOGRAPH, employee.START_DATE, employee.END_DATE,employee.ADDRESS, employee.COMMENTS], (err, rows, fields) => {
  if (!err)
  rows.forEach(element => {
  if(element.constructor == Array)
  res.send('New Employee ID : '+ element[0].EMPLOYEE_ID);
  });
  else
  console.log(err);
  })
  });



