<template>
  <q-page class="window-height window-width row justify-center items-center"
  style="background: linear-gradient(#012E57, #012E57);"
  >
    <div style=" margin-top:50px">
       <q-img
      alt="Quasar logo "
      src="~assets/logo1.png"
      hight="100px"
      width="50px"
      
    >
    </q-img>
    </div>

    <div >
      <div  >
       
      <h4 class="text- frutiger text-white text-center q-pa-none text-bold">Login</h4>  
      </div>
      <div style=" margin-bottom:300px" >
        <q-card fixed-center >
          <q-card-section>
            <q-form class="text-frutiger q-px-sm q-pt-xl q-pb-lg">
              <q-input square filled clearable v-model="Number" type="number" label="Phone-Number" />
            </q-form>
          </q-card-section>
          <q-card-actions class="q-px-md">
            <q-btn unelevated size="lg" class="full-width" text-color="white" label="Login" style="background: linear-gradient(#f0951f, #f0951f);"  />
             
          </q-card-actions>
          <q-card-section class="text-center q-pa-none">
            <p class="text-frutiger text-grey-6">Not reigistered? <q-btn unelevated color="#012E57" label="" > <a :href="signup">Sign Up</a></q-btn></p>
          </q-card-section>
        </q-card>
       
      </div>
    </div>
     <q-footer style="background: linear-gradient(#012E57, #012E57);">
        <q-toolbar>
          <q-toolbar-title class="text-frutiger text-center q-pa-none" >By Signing up, you agree to T&C </q-toolbar-title>
        </q-toolbar>
      </q-footer>
  </q-page>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      email: '',
      password: '',
      signup:'#/signup'
    }
  }


}
</script>

<style>
.q-card {
  width: 360px;
}
</style>